package steps;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import runner.Runner;

public class Definition extends Runner {
	
//	static WebDriver dr=null;	
	
		
	@Given("^Application is up and running$")
	public void application_is_up_and_running()  {
	 
		ChromeOptions op= new ChromeOptions();
	//	op.addArguments("--disable-infobars");
		op.addArguments("--start-maximized");
		
		//To Handle SSL certificate
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		op.setCapability(ChromeOptions.CAPABILITY, cap);
		
		dr= new ChromeDriver(op);	
		dr.get("http://newtours.demoaut.com/");
	}

	@When("^Please enter username and password$")
	public void user_enters_username_and_password()  {
		
		dr.findElement(By.name("userName")).sendKeys("mercury");
		dr.findElement(By.name("password")).sendKeys("mercury");
		dr.findElement(By.name("login")).click();	    
	}

	@Then("^User should be logged in Successfully$")
	public void user_should_be_logged_in_Successfully() {
	  if(dr.findElements(By.xpath("//img[@src='/images/masts/mast_flightfinder.gif']")).size()>=1)
		  System.out.println("Correct page");
	  else 
		  System.out.println("NOT a Correct page");  
	}
	
	@Given("^User is logged in Successfully$")
	public void user_is_logged_in_Successfully()  {
		if(dr.findElements(By.xpath("//img[@src='/images/masts/mast_flightfinder.gif']")).size()>=1)
			  System.out.println("Pass");
		  else 
			  System.out.println("Fail"); 
	}

	@When("^Select booking details$")
	public void select_booking_details()  {
		dr.findElement(By.xpath("//input[@value='oneway']")).click();
		Select s1 = new Select(dr.findElement(By.xpath("//select[@name='passCount']")));
		s1.selectByVisibleText("2");
		
		//Click Continue
		dr.findElement(By.xpath("//input[@src='/images/forms/continue.gif']")).click();
	}

	@Then("^Select flight page should be opened$")
	public void select_flight_page_should_be_opened() {
		// To validate Page is 'Select flight'
		String url = dr.getCurrentUrl();
		if (url.equals("http://newtours.demoaut.com/mercuryreservation2.php"))
			System.out.println("URL is correct");
		else 
			System.out.println("URL is NOT correct");
	}
	
	@When("^User enters (.*?) and (.*?)$")
	public void user_enters_username_and_password(String username, String password)  {
		
		dr.findElement(By.name("userName")).sendKeys(username);
		dr.findElement(By.name("password")).sendKeys(password);
		dr.findElement(By.name("login")).click();		
	}
	
	
	

	

}
