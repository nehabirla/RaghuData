package runner;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions (
		features = {"Features"},
		glue = {"steps"},
		plugin = {"html:FeatureFiles/Raghu"},
		tags = {"~@Functional, @Sanity"}
		)
// plugin : report folder
// ~ : skip execution

public class Runner {
	
	public static WebDriver dr;
	
	@BeforeClass
	public static void setUp()
	{	System.out.println("This is Before class.");		
	     dr=null;	
	}
	@AfterClass
	public static void tearDown()
	{	System.out.println("This is after class.");
		dr.close();
	}
	
}
41