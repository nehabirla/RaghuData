$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Feature1.feature");
formatter.feature({
  "line": 2,
  "name": "Title of your feature",
  "description": "I want to use this template for my feature file",
  "id": "title-of-your-feature",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Sanity"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Login",
  "description": "",
  "id": "title-of-your-feature;login",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "Application is up and running",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Please enter username and password",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "User should be logged in Successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "Definition.application_is_up_and_running()"
});
formatter.result({
  "duration": 4543804539,
  "status": "passed"
});
formatter.match({
  "location": "Definition.user_enters_username_and_password()"
});
formatter.result({
  "duration": 4637476282,
  "status": "passed"
});
formatter.match({
  "location": "Definition.user_should_be_logged_in_Successfully()"
});
formatter.result({
  "duration": 32412379,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "booking details",
  "description": "",
  "id": "title-of-your-feature;booking-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "User is logged in Successfully",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "Select booking details",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Select flight page should be opened",
  "keyword": "Then "
});
formatter.match({
  "location": "Definition.user_is_logged_in_Successfully()"
});
formatter.result({
  "duration": 14461054,
  "status": "passed"
});
formatter.match({
  "location": "Definition.select_booking_details()"
});
formatter.result({
  "duration": 898578620,
  "status": "passed"
});
formatter.match({
  "location": "Definition.select_flight_page_should_be_opened()"
});
formatter.result({
  "duration": 9092358,
  "status": "passed"
});
});