package com.practice.cucumber.testCucumber.TestRunner;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions (
		features = {"src/test/java/resources"},
		glue = {"src/test/java/stepDef"},
		tags = {"@Sanity"}
		)


public class Runner {
	
	public static WebDriver dr;
	
	@BeforeClass
	public static void setUp()
	{	System.out.println("This is Before class.");		
	     dr=null;	
	}
	@AfterClass
	public static void tearDown()
	{	System.out.println("This is after class.");
		dr.close();
	}	
}