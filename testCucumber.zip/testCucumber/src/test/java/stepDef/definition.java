package stepDef;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import com.practice.cucumber.testCucumber.TestRunner.Runner;

public class definition extends Runner {
	
	@Given("Application is up and running")
	public void application_is_up_and_running() {
		System.out.println("inside application_is_up_and_running");		
			ChromeOptions op= new ChromeOptions();
		//	op.addArguments("--disable-infobars");
			op.addArguments("--start-maximized");
			
			//To Handle SSL certificate
			DesiredCapabilities cap = new DesiredCapabilities();
			cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			op.setCapability(ChromeOptions.CAPABILITY, cap);
			
			dr= new ChromeDriver(op);	
			dr.get("http://newtours.demoaut.com/");
	}

	@When("Please enter username and password")
	public void please_enter_username_and_password() {
	System.out.println("inside user_enters_username_and_password");				
			dr.findElement(By.name("userName")).sendKeys("mercury");
			dr.findElement(By.name("password")).sendKeys("mercury");
			dr.findElement(By.name("login")).click();
	}

	@Then("User should be logged in Successfully")
	public void user_should_be_logged_in_Successfully() {
			System.out.println("inside user_should_be_logged_in_Successfully");		
		  if(dr.findElements(By.xpath("//img[@src='/images/masts/mast_flightfinder.gif']")).size()>=1)
			  System.out.println("Correct page");
		  else 
			  System.out.println("NOT a Correct page");
	}
	
	
	


}
